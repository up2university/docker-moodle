Pumukit filter

This filter will replace any link generated with pumukit repository
with an iframe that will retrieve the content served by pumukit.
window.onload = function() {
    document.querySelector('.atto_pumukitpr_button_pumukitpr').click();
};